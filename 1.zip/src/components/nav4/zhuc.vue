<!--  -->
<template>
<div class='zhuc'>
    <div class="zhuc1">
       <p>账号登录</p>
       <p><small>严选商城欢迎你</small></p>
       <div>

       </div>
        <p>
            <router-link to="/">
                    忘记密码
            </router-link>
        </p>
    </div>
</div>
</template>

<script>

import axios from "axios";
export default {
data() {
return {

};
},
methods: {

},
components: {

},
computed: {

},
created() {

},
}
</script>
<style  scoped>
@import url('../../assets/css/zhuc/zhuc.css');
</style>