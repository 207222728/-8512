/**
 * product-service.js Created by SmallFour on 2019/10/22/14:16
 */

// 第二个文件：M层

/*
* M : 数据
* V： 视图
* C： 业务逻辑层
* */

import HTTP from '../utils/http'
const _http = new HTTP()
class Product {
  // list方法
  list () {
    return _http.request({
      url: 'banner/list'
    })
  }
  // detail方法分类渲染
  detail () {
    return _http.request({
      url: 'shop/goods/category/all'
    })
  }
  // 分类列表页
  liebiao () {
    return _http.request({
      url: 'shop/goods/list'
    })
  }
  // 分类列表详情页
  // xiangq (id) {
  //   console.log(id)
  //   return _http.request({
  //     url: 'shop/goods/detail',
  //     data: {
  //       id: id
  //     }
  //   })
  // }
  //
}

export default Product
