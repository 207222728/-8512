/**
 * order-service.js Created by SmallFour on 2019/10/22/14:26
 */
class Order {

}
export default Order
