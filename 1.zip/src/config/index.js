/**
 * index.js Created by SmallFour on 2019/10/22/15:18
 */
const config = {
  baseUrl: 'https://api.it120.cc/small4/'
}
export default config
