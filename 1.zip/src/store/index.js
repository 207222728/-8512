/**
 * index.js Created by SmallFour on 2019/9/28/9:07
 */
import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)

const store = new Vuex.Store({
  // 状态管理对象
  state: {
    list: [
      {
        name: '全部分类',
        done: false,
        type: '',
        done1: false
      },
      {
        name: '居家生活',
        done: false,
        type: 'jujia2',
        done1: false
      },
      {
        name: '配饰装饰',
        done: false,
        type: 'peishi2',
        done1: false
      },
      {
        name: '新品服装',
        done: false,
        type: 'fuzhuang2',
        done1: false
      },
      {
        name: '日用电器',
        done: false,
        type: 'dianqi2',
        done1: false
      }
    ],
    list1: [],
    // 列表图片
    list2: [],
    // 列表详情
    list3: [],
    // 专栏数据
    list4: [],
    done: true
  },
  // mutations
  mutations: {
    // 筛选
    add (state, v) {
      v.done = true
      if (v.done === true) {
        state.list1.forEach(d => {
          if (v.type === '') {
            console.log()
            d.isUse = true
          } else if (v.type === d.type) {
            d.isUse = true
          } else {
            d.isUse = false
          }
        })
      }
    },
    bl (state) {
      state.done = false
    },
    bl1 (state) {
      state.done = true
    }


  }
})

export default store
