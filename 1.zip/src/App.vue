<template>
  <div id="app">
    <Hello></Hello>
  </div>
</template>

<script>
import Hello from "./components/nav2/HelloWorld"
import './assets/js/index'
export default {
  name: 'App',
  components:{
    Hello
  }
}
</script>
<style>
@import url('./assets/css/App/index.css');
.bottom{
  width: 100%;
  height: 50px;
  background: #fff;
  position: absolute;
  bottom: 0;
}
.hello{
  box-sizing: border-box;
  padding-bottom: 50px;
}
</style>
